
import numpy as np
from matplotlib.pyplot import *

x=np.load('loadspectra.npz')

f=x['f'];
s290_ceil=x['s290_ceil']
s290_abs=x['s290_abs']
s290_ceilcooler=x['s290_ceilcooler']
s290_ceilcoolerabs=x['s290_ceilcoolerabs']
s290_abs=x['s290_abs']
s77_ceilcoolerabs=x['s77_ceilcoolerabs']
s290_t=x['s290_t']
s290_t2=x['s290_t2']
s77_t=x['s77_t']
s77_t2=x['s77_t2']


figure(1)
clf()
plot(f,s290_ceil);plot(f,s290_ceilcooler);plot(f,s290_ceilcoolerabs);
plot(f,s290_abs);plot(f,s77_ceilcoolerabs);
xlabel('f (MHz)');ylabel('Power (ADU^2)');grid('on');
legend(('ceiling','ceiling + cooler','ceiling + cooler + 290K absorber','290K cone absorber','ceiling + cooler + 77K absorber'),fontsize=8)
savefig('Tys_fig1.png')

figure(2)
clf()
plot(f,s290_t,'b');plot(f,s290_t2,'b--');plot(f,s77_t,'g');plot(f,s77_t2,'g--');
grid('on');xlabel('f (MHz)');ylabel('Power (ADU^2)');
legend(('290 K terminator, poorly heat sunk LNA','290 K terminator, well heat sunk LNA','77 K terminator, poorly heat sunk LNA','77 K terminator, well heat sunk LNA'),fontsize=8);
savefig('Tys_fig2.png')

Tsys_t=[]
for k in range(2048):
    p=np.polyfit([77,290],[s77_t[k],s290_t[k]],deg=1)
    Tsys_t.append(p[1]/p[0])

Tsys_t2=[]
for k in range(2048):
    p=np.polyfit([77,290],[s77_t2[k],s290_t2[k]],deg=1)
    Tsys_t2.append(p[1]/p[0])

Tsys_ant=[]
for k in range(2048):
    p=np.polyfit([77,290],[s77_ceilcoolerabs[k],s290_abs[k]],deg=1)
    Tsys_ant.append(p[1]/p[0])

figure(3)
clf()
plot(f,Tsys_t);plot(f,Tsys_t2);plot(f,Tsys_ant)
xlabel('f (MHz)')
ylabel('Tsys (K)')
grid('on');ylim(50,250)
legend(('terminator, poorly heat sunk LNA','terminator, well heat sunk LNA','antenna (ceil + cool + abs for 77 K and 290 K cones for 290 K)'),fontsize=8)
savefig('Tys_fig3.png')



